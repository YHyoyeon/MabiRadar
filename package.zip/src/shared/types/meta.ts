export interface Meta {
    method: string;
    enable: boolean;
}