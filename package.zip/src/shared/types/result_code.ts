export enum ResultCode {
    Fail = 0,
    Success = 1,
}