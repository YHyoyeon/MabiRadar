export const config = {
    nodeEnv: 'local',
    radarServer: {
        serverType: 'RADAR_SERVER',
        id: 1000,
        name: 'radar_server',
        port: 13000,
    }
};