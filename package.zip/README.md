# mabi-radar
My own stock analysis application, made by me and for me.
